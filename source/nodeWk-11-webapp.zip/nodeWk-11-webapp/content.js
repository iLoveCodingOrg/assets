var contentMap = {
  '/' : '<h1>Welcome to the site</h1>',
  '/contact' : '<h1>Contact Page</h1>',
  '/about' : '<h1>About Page</h1>',
  '/users' : '<h1>Users Page</h1>',
  '/privacy' : '<h1>Privacy Page</h1>'
}

exports.contentMap = contentMap;