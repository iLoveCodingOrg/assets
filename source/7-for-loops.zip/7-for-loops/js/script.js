for(var i=0; i<=10000; i++){
  // do something
  if(i%3 === 0){
    document.write(i + '<br/>');  
  }
}