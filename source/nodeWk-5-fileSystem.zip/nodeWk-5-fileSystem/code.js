var fs = require('fs');

fs.readFile('/Users/azizali/desktop/lorem.txt', 'utf8', function(err, data){
  if(err){
    console.log(err);
  }
  console.log('Finished Reading');
});

console.log('hi, there');



fs.writeFile('/Users/azizali/desktop/mydoc2.txt', 'some text', 'utf8', function(err,data){
  if(err){
    console.log(err);
  }
  console.log(data);
});

