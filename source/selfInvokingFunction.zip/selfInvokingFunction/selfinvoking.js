// Self Invoking Anonymous Function


!function(){
  console.log('i am doing');

  var a = 'some value';

  function doing(){
    console.log('i am the function');
  }

  
}();
