var myname = "Aziz";
console.log(myname + " is my name :)");