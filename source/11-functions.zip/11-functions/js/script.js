var add = function(a, b){
  var c = a + b;
  console.log(c);
  return 50;
}

document.write(add(2, 5));


