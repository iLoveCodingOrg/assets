myAppController.controller('FirstController', [function(){
  this.text = 'I am first controller';
}]);