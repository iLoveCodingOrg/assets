myAppController.controller('SecondController', [function(){
  this.text = 'I am second controller';
}]);