var app = angular.module('myApp', 
                         ['myApp.controllers',
                         'ngRoute',
                         'ngAnimate']
                        );
app.config([function(){
  
}]);