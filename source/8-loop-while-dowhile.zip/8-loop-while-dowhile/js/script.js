var i = 0;
// while(i<100){
//   if(i%3 === 0){
//     document.write(i + '<br />');
//   }
//   i++;
// }


do{
  document.write('hello');
  i++;
}while(i<2);