    app.controller('GoodController', function(){
      var g = this;
      g.interest = "Cricket";
    });