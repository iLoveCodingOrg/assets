// Difference Between Functions & Methods

function doSomething(param){
  console.log(param + '1');
  this.myMethod = function (){
    console.log(param + '2')
  }
}

var instanceObject = new doSomething('Hi Again');
instanceObject.myMethod()

//doSomething('Say Hi').myMethod();

jQuery('document').ready(function(){});



var arr = ['value1', '2'];
arr.push('3');
