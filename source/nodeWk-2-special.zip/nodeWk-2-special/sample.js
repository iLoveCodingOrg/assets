// Synchronous / Blocking
var output = getDataFromDatabase('names');
console.log('Hi There');
console.log(output);



// Asynchronous / Non-blocking
getDataFromDatabase('name', function(output){
  console.log(output);
});
console.log('Hi There');


























// Event Driven
readStream.on('data', function(data) {
  console.log('recieved some data');
});

readStream.on('end', function() {
  console.log('file ended');
});




















// Event Driven
server.on('request', function () {
  console.log('We have our connection established');
});






















