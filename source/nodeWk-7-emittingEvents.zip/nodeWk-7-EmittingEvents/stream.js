var fs = require('fs');

var readStream = fs.createReadStream('lorem.txt');
readStream.setEncoding('utf8');

var counter = 0
readStream.addListener('data', dataCounter);
readStream.addListener('data', dataPrinter);

readStream.addListener('end', function(){
  console.log(counter);
});

function dataCounter(datacoming){
  counter = counter + 1;
  if(counter === 5){
    // readStream.removeListener('data', dataCounter);
    readStream.removeAllListeners('data');
  }
}

function dataPrinter(data){
  console.log('data chunk length: ' + data.length);
}





