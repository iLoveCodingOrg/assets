var arr = [];

arr[0] = 'Aziz';
arr[1] = 'John';
arr[2] = 'Jim';

// document.write(arr + '<br/>');

// var name = prompt('What is your name?');

// arr.push(name);

// document.write(arr + '<br/>');

for(var i=0; i<arr.length; i++){
  document.write(arr[i] + '<br/>');
}